"""Views das telas HTML (a API JSON está em api.py)."""
from django.contrib import messages
from django.http import JsonResponse
from django.shortcuts import get_object_or_404, redirect, render
from django.views.csrf import csrf_failure

from . import regras
from .forms import DisponibilidadeForm, FiltroReservasForm, ReservaForm
from .models import Reserva, Veiculo


def home(request):
    contexto = {
        "total_veiculos": Veiculo.objects.count(),
        "total_reservas": Reserva.objects.count(),
        "reservas_futuras": Reserva.objects.filter(data__gte=regras.hoje()).count(),
    }
    return render(request, "reservas/home.html", contexto)


def veiculos_lista(request):
    return render(request, "reservas/veiculos.html", {"veiculos": Veiculo.objects.all()})


def reservas_lista(request):
    filtro = FiltroReservasForm(request.GET)
    reservas = Reserva.objects.select_related("veiculo")
    if filtro.is_valid():
        if filtro.cleaned_data["data"]:
            reservas = reservas.filter(data=filtro.cleaned_data["data"])
        if filtro.cleaned_data["veiculo"]:
            reservas = reservas.filter(veiculo=filtro.cleaned_data["veiculo"])
    return render(request, "reservas/reservas.html", {"reservas": reservas, "filtro": filtro, "hoje": regras.hoje()})


def reserva_criar(request):
    if request.method == "POST":
        form = ReservaForm(request.POST)
        if form.is_valid():
            reserva = form.save()
            messages.success(request, f"Reserva registrada: {reserva}.")
            return redirect("reservas:reservas")
        messages.error(request, "A reserva não foi registrada. Corrija os problemas indicados.")
    else:
        # A tela de disponibilidade envia os dados já preenchidos pela query string.
        form = ReservaForm(initial=request.GET.dict())
    return render(request, "reservas/reserva_form.html", {"form": form, "titulo": "Nova reserva"})


def reserva_editar(request, pk):
    reserva = get_object_or_404(Reserva, pk=pk)
    if request.method == "POST":
        form = ReservaForm(request.POST, instance=reserva)
        if form.is_valid():
            form.save()
            messages.success(request, "Reserva atualizada com sucesso.")
            return redirect("reservas:reservas")
        messages.error(request, "A reserva não foi atualizada. Corrija os problemas indicados.")
    else:
        form = ReservaForm(instance=reserva)
    return render(request, "reservas/reserva_form.html", {"form": form, "titulo": f"Editar reserva #{reserva.pk}"})


def reserva_excluir(request, pk):
    reserva = get_object_or_404(Reserva, pk=pk)
    if request.method == "POST":
        reserva.delete()
        messages.success(request, "Reserva excluída. O veículo ficou livre no período.")
        return redirect("reservas:reservas")
    return render(request, "reservas/reserva_excluir.html", {"reserva": reserva})


def disponibilidade(request):
    """Consulta de disponibilidade antes de cadastrar a reserva."""
    form = DisponibilidadeForm(request.GET) if request.GET else DisponibilidadeForm()
    disponiveis = indisponiveis = None
    if request.GET and form.is_valid():
        d = form.cleaned_data
        disponiveis, indisponiveis = regras.consultar_disponibilidade(
            d["data"], d["saida"], d["retorno"], d["passageiros"]
        )
    return render(
        request,
        "reservas/disponibilidade.html",
        {"form": form, "disponiveis": disponiveis, "indisponiveis": indisponiveis},
    )


def falha_csrf(request, reason=""):
    """Em /api/ a falha de CSRF é devolvida como JSON; nas telas, a página padrão."""
    if request.path.startswith("/api/"):
        return JsonResponse(
            {
                "erro": "Falha na verificação CSRF. Obtenha um token em GET /api/csrf/ e envie-o "
                "no cabeçalho X-CSRFToken junto com o cookie csrftoken.",
                "detalhe": reason,
            },
            status=403,
            json_dumps_params={"ensure_ascii": False},
        )
    return csrf_failure(request, reason=reason)
