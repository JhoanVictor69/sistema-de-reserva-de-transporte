"""Cadastra a frota e as quatro reservas de referência do enunciado.

Uso:
    python manage.py carregar_dados
    python manage.py carregar_dados --apenas-frota

O comando pode ser executado várias vezes: usa get_or_create e não duplica registros.

As reservas do enunciado têm datas de agosto/2026. Dependendo de quando o comando
for executado, essas datas podem estar no passado. Por isso elas são gravadas
diretamente com o ORM (Reserva.objects.get_or_create), SEM passar por Reserva.clean():
são dados históricos de referência. A regra "não reservar no passado" continua valendo
para qualquer reserva nova criada pela API, pelas telas ou pelo Admin.
"""
from datetime import date, time

from django.core.management.base import BaseCommand
from django.db import transaction

from reservas.models import Reserva, Veiculo

FROTA = (
    [(f"VL-{n:02d}", Veiculo.LEVE, 4) for n in range(1, 9)]
    + [("VC-01", Veiculo.COLETIVO, 18), ("VC-02", Veiculo.COLETIVO, 18)]
)

# Dados que constam no enunciado: veículo, data, horários e atividade.
RESERVAS_ENUNCIADO = [
    ("VL-01", date(2026, 8, 18), time(8, 0), time(10, 0), "Reunião administrativa"),
    ("VL-03", date(2026, 8, 18), time(13, 0), time(15, 0), "Inspeção técnica"),
    ("VC-01", date(2026, 8, 19), time(9, 0), time(12, 0), "Treinamento"),
    ("VL-05", date(2026, 8, 20), time(14, 0), time(17, 0), "Visita externa"),
]

# Campos que o enunciado NÃO informa foram preenchidos com valores neutros.
# passageiros=1 é o menor valor válido (serve para qualquer veículo).
PREENCHIMENTO_PADRAO = {
    "solicitante": "Dado inicial do enunciado",
    "setor": "COSEG",
    "origem": "Porto do Itaqui",
    "destino": "Não informado no enunciado",
    "passageiros": 1,
    "observacoes": "Reserva de referência do enunciado do PBL 1 (campos não informados preenchidos com valores padrão).",
}


class Command(BaseCommand):
    help = "Cadastra os 10 veículos da frota e as 4 reservas de referência do enunciado."

    def add_arguments(self, parser):
        parser.add_argument(
            "--apenas-frota",
            action="store_true",
            help="Cadastra somente os veículos, sem as reservas do enunciado.",
        )

    def escrever(self, texto, opcoes):
        if opcoes["verbosity"] > 0:
            self.stdout.write(texto)

    @transaction.atomic
    def handle(self, *args, **opcoes):
        novos = 0
        for codigo, categoria, capacidade in FROTA:
            _, criado = Veiculo.objects.get_or_create(
                codigo=codigo, defaults={"categoria": categoria, "capacidade": capacidade}
            )
            novos += criado
        self.escrever(f"Frota: {novos} veículo(s) criado(s); total no banco: {Veiculo.objects.count()}.", opcoes)

        if opcoes["apenas_frota"]:
            return

        criadas = 0
        for codigo, dia, saida, retorno, atividade in RESERVAS_ENUNCIADO:
            _, criada = Reserva.objects.get_or_create(
                veiculo=Veiculo.objects.get(codigo=codigo),
                data=dia,
                horario_saida=saida,
                defaults={"horario_retorno": retorno, "atividade": atividade, **PREENCHIMENTO_PADRAO},
            )
            criadas += criada
        self.escrever(f"Reservas do enunciado: {criadas} criada(s); total no banco: {Reserva.objects.count()}.", opcoes)
        self.escrever(self.style.SUCCESS("Dados iniciais carregados."), opcoes)
