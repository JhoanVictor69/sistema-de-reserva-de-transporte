"""Regras de negócio das reservas, separadas das views e dos formulários.

Cada função recebe valores simples e devolve uma lista de mensagens de erro
(lista vazia = regra cumprida). Assim cada regra pode ser lida e testada sozinha.
"""
from collections import defaultdict
from datetime import date, time

from django.core.exceptions import NON_FIELD_ERRORS
from django.utils import timezone

CAPACIDADE_MAXIMA_FROTA = 18  # maior capacidade existente (veículos coletivos)


def hoje():
    """Data atual no fuso configurado em TIME_ZONE (e não a data UTC)."""
    return timezone.localdate()


# ---------------------------------------------------------------- regra 1
def validar_passageiros(passageiros, veiculo=None):
    if not isinstance(passageiros, int):
        return []
    if passageiros <= 0:
        return ["A quantidade de passageiros deve ser de pelo menos 1."]
    if passageiros > CAPACIDADE_MAXIMA_FROTA:
        return [
            f"Solicitação rejeitada: {passageiros} passageiros excede a capacidade "
            f"máxima da frota ({CAPACIDADE_MAXIMA_FROTA}). Divida a atividade em mais de uma reserva."
        ]
    if veiculo is not None and passageiros > veiculo.capacidade:
        sugestao = " Escolha um veículo coletivo." if veiculo.categoria == "LEVE" else ""
        return [
            f"O veículo {veiculo.codigo} comporta no máximo {veiculo.capacidade} "
            f"passageiros, mas foram informados {passageiros}.{sugestao}"
        ]
    return []


# ---------------------------------------------------------------- regra 2
def validar_data(data, data_original=None):
    """Impede datas passadas.

    Se a reserva já existia e a data não foi alterada (data_original), a regra não é
    aplicada: assim é possível corrigir observações de um registro antigo.
    """
    if not isinstance(data, date):
        return []
    if data_original is not None and data == data_original:
        return []
    if data < hoje():
        return [f"A data {data:%d/%m/%Y} já passou. Informe a data de hoje ou uma data futura."]
    return []


# ---------------------------------------------------------------- regra 3
def validar_horarios(saida, retorno):
    if not (isinstance(saida, time) and isinstance(retorno, time)):
        return []
    if retorno <= saida:
        return [
            f"O horário de retorno ({retorno:%H:%M}) deve ser posterior ao horário "
            f"de saída ({saida:%H:%M})."
        ]
    return []


# ---------------------------------------------------------------- regra 4
def buscar_conflitos(veiculo, data, saida, retorno, ignorar_pk=None):
    """Consulta o banco (ORM) por reservas do mesmo veículo e data que se sobrepõem.

    Sobreposição: nova_saida < retorno_existente  E  novo_retorno > saida_existente.
    Comparações estritas: se uma reserva termina às 10:00 e outra começa às 10:00,
    NÃO há conflito (o veículo é liberado e reutilizado no mesmo instante).
    """
    from .models import Reserva

    conflitos = Reserva.objects.filter(
        veiculo=veiculo,
        data=data,
        horario_saida__lt=retorno,
        horario_retorno__gt=saida,
    )
    if ignorar_pk is not None:
        conflitos = conflitos.exclude(pk=ignorar_pk)  # na edição, ignora a própria reserva
    return conflitos.select_related("veiculo")


def validar_conflito(veiculo, data, saida, retorno, ignorar_pk=None):
    mensagens = []
    for outra in buscar_conflitos(veiculo, data, saida, retorno, ignorar_pk):
        mensagens.append(
            f"Conflito de horário: o veículo {veiculo.codigo} já está reservado em "
            f"{outra.data:%d/%m/%Y} das {outra.horario_saida:%H:%M} às "
            f"{outra.horario_retorno:%H:%M} ({outra.atividade}, solicitante: {outra.solicitante})."
        )
    return mensagens


# ---------------------------------------------------------------- conjunto
def validar_reserva(reserva):
    """Executa todas as regras e devolve {campo: [mensagens]} (vazio se tudo certo).

    Campos ausentes ou inválidos já foram tratados pelo formulário; aqui eles são
    simplesmente ignorados para não gerar erros em cascata.
    """
    erros = defaultdict(list)
    veiculo = reserva.veiculo if reserva.veiculo_id else None

    data_original = None
    if reserva.pk:
        data_original = (
            type(reserva).objects.filter(pk=reserva.pk).values_list("data", flat=True).first()
        )

    erros["passageiros"] += validar_passageiros(reserva.passageiros, veiculo)
    erros["data"] += validar_data(reserva.data, data_original)
    erros["horario_retorno"] += validar_horarios(reserva.horario_saida, reserva.horario_retorno)

    if veiculo is not None and not veiculo.disponivel:
        erros["veiculo"].append(
            f"O veículo {veiculo.codigo} está fora de operação e não aceita novas reservas."
        )

    horarios_ok = (
        isinstance(reserva.horario_saida, time)
        and isinstance(reserva.horario_retorno, time)
        and reserva.horario_retorno > reserva.horario_saida
    )
    if veiculo is not None and isinstance(reserva.data, date) and horarios_ok:
        erros[NON_FIELD_ERRORS] += validar_conflito(
            veiculo, reserva.data, reserva.horario_saida, reserva.horario_retorno, reserva.pk
        )

    return {campo: mensagens for campo, mensagens in erros.items() if mensagens}


# ---------------------------------------------------------------- disponibilidade
def consultar_disponibilidade(data, saida, retorno, passageiros=None):
    """Devolve (disponiveis, indisponiveis) para a data e o intervalo informados.

    disponiveis: lista de Veiculo.
    indisponiveis: lista de (Veiculo, motivo).
    """
    from .models import Reserva, Veiculo

    ocupados = {}
    sobrepostas = Reserva.objects.filter(
        data=data, horario_saida__lt=retorno, horario_retorno__gt=saida
    )
    for reserva in sobrepostas:
        ocupados.setdefault(reserva.veiculo_id, reserva)

    disponiveis, indisponiveis = [], []
    for veiculo in Veiculo.objects.all():
        if not veiculo.disponivel:
            indisponiveis.append((veiculo, "Veículo fora de operação."))
        elif veiculo.pk in ocupados:
            r = ocupados[veiculo.pk]
            indisponiveis.append(
                (veiculo, f"Reservado das {r.horario_saida:%H:%M} às {r.horario_retorno:%H:%M} ({r.atividade}).")
            )
        elif passageiros and passageiros > veiculo.capacidade:
            indisponiveis.append(
                (veiculo, f"Capacidade insuficiente ({veiculo.capacidade} lugares para {passageiros} passageiros).")
            )
        else:
            disponiveis.append(veiculo)
    return disponiveis, indisponiveis
