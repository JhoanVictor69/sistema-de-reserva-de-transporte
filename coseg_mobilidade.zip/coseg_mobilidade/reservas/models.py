from django.core.exceptions import ValidationError
from django.db import models

from . import regras


class Veiculo(models.Model):
    LEVE = "LEVE"
    COLETIVO = "COLETIVO"
    CATEGORIAS = [(LEVE, "Leve"), (COLETIVO, "Coletivo")]

    codigo = models.CharField("código", max_length=10, unique=True)
    categoria = models.CharField("categoria", max_length=10, choices=CATEGORIAS)
    capacidade = models.PositiveSmallIntegerField("capacidade (passageiros)")
    disponivel = models.BooleanField(
        "em operação",
        default=True,
        help_text="Desmarque para impedir novas reservas (ex.: veículo em manutenção).",
    )

    class Meta:
        ordering = ["codigo"]
        verbose_name = "veículo"
        verbose_name_plural = "veículos"

    def __str__(self):
        return f"{self.codigo} — {self.get_categoria_display()} ({self.capacidade} lugares)"


class Reserva(models.Model):
    solicitante = models.CharField("solicitante", max_length=120)
    setor = models.CharField("setor", max_length=80)
    atividade = models.CharField("atividade", max_length=120)
    origem = models.CharField("origem", max_length=120)
    destino = models.CharField("destino", max_length=120)
    data = models.DateField("data")
    horario_saida = models.TimeField("horário de saída")
    horario_retorno = models.TimeField("horário de retorno")
    passageiros = models.SmallIntegerField("quantidade de passageiros")
    veiculo = models.ForeignKey(
        Veiculo,
        on_delete=models.PROTECT,  # não permite apagar um veículo que tenha reservas
        related_name="reservas",
        verbose_name="veículo",
    )
    observacoes = models.TextField("observações", blank=True)
    criado_em = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ["data", "horario_saida"]
        verbose_name = "reserva"
        verbose_name_plural = "reservas"
        indexes = [models.Index(fields=["veiculo", "data"])]

    def __str__(self):
        return (
            f"{self.veiculo.codigo} · {self.data:%d/%m/%Y} · "
            f"{self.horario_saida:%H:%M}–{self.horario_retorno:%H:%M} · {self.atividade}"
        )

    def clean(self):
        """Aplica as regras de negócio (ver regras.py).

        Como está no model, vale para o formulário HTML, para a API e para o Admin.
        """
        super().clean()
        erros = regras.validar_reserva(self)
        if erros:
            raise ValidationError(erros)
