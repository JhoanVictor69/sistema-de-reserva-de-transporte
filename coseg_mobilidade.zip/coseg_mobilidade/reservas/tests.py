import json
from datetime import date, time, timedelta

from django.core.management import call_command
from django.test import Client, TestCase
from django.urls import reverse
from django.utils import timezone

from .models import Reserva, Veiculo


def dias_a_frente(n=7):
    return timezone.localdate() + timedelta(days=n)


class BaseTestCase(TestCase):
    """Carrega a frota com o comando oficial antes de cada teste."""

    def setUp(self):
        call_command("carregar_dados", "--apenas-frota", verbosity=0)

    def dados(self, **alterados):
        base = {
            "solicitante": "Maria Souza",
            "setor": "Operações",
            "atividade": "Reunião externa",
            "origem": "Porto do Itaqui",
            "destino": "Centro Administrativo",
            "data": dias_a_frente().isoformat(),
            "horario_saida": "08:00",
            "horario_retorno": "10:00",
            "passageiros": 3,
            "veiculo": "VL-01",
            "observacoes": "",
        }
        base.update(alterados)
        return {k: v for k, v in base.items() if v is not ...}  # ... = remover o campo

    def post(self, dados, client=None):
        return (client or self.client).post(
            reverse("reservas:api_reservas"), json.dumps(dados), content_type="application/json"
        )

    def put(self, pk, dados):
        return self.client.put(
            reverse("reservas:api_reserva_detalhe", args=[pk]), json.dumps(dados), content_type="application/json"
        )

    def criar(self, **alterados):
        resposta = self.post(self.dados(**alterados))
        self.assertEqual(resposta.status_code, 201, resposta.content)
        return Reserva.objects.get(pk=resposta.json()["reserva"]["id"])


# ---------------------------------------------------------------- frota e comando
class FrotaEComandoTests(TestCase):
    def test_comando_cadastra_dez_veiculos(self):
        call_command("carregar_dados", verbosity=0)
        self.assertEqual(Veiculo.objects.count(), 10)
        self.assertEqual(Veiculo.objects.filter(categoria="LEVE", capacidade=4).count(), 8)
        self.assertEqual(Veiculo.objects.filter(categoria="COLETIVO", capacidade=18).count(), 2)
        codigos = set(Veiculo.objects.values_list("codigo", flat=True))
        esperados = {f"VL-0{n}" for n in range(1, 9)} | {"VC-01", "VC-02"}
        self.assertEqual(codigos, esperados)

    def test_comando_cadastra_reservas_do_enunciado(self):
        call_command("carregar_dados", verbosity=0)
        self.assertEqual(Reserva.objects.count(), 4)
        r = Reserva.objects.get(veiculo__codigo="VL-01")
        self.assertEqual((r.data, r.horario_saida, r.horario_retorno), (date(2026, 8, 18), time(8), time(10)))
        self.assertEqual(r.atividade, "Reunião administrativa")
        self.assertTrue(Reserva.objects.filter(veiculo__codigo="VC-01", data=date(2026, 8, 19), horario_saida=time(9), horario_retorno=time(12)).exists())
        self.assertTrue(Reserva.objects.filter(veiculo__codigo="VL-03", data=date(2026, 8, 18), horario_saida=time(13), horario_retorno=time(15)).exists())
        self.assertTrue(Reserva.objects.filter(veiculo__codigo="VL-05", data=date(2026, 8, 20), horario_saida=time(14), horario_retorno=time(17)).exists())

    def test_comando_e_repetivel_sem_duplicar(self):
        call_command("carregar_dados", verbosity=0)
        call_command("carregar_dados", verbosity=0)
        self.assertEqual(Veiculo.objects.count(), 10)
        self.assertEqual(Reserva.objects.count(), 4)

    def test_dados_historicos_nao_liberam_novas_reservas_no_passado(self):
        call_command("carregar_dados", verbosity=0)
        passado = (timezone.localdate() - timedelta(days=1)).isoformat()
        corpo = {
            "solicitante": "A", "setor": "B", "atividade": "C", "origem": "D", "destino": "E",
            "data": passado, "horario_saida": "08:00", "horario_retorno": "09:00",
            "passageiros": 1, "veiculo": "VL-02",
        }
        resposta = self.client.post(reverse("reservas:api_reservas"), json.dumps(corpo), content_type="application/json")
        self.assertEqual(resposta.status_code, 400)
        self.assertIn("data", resposta.json()["erros"])


# ---------------------------------------------------------------- CRUD e persistência
class CrudTests(BaseTestCase):
    def test_criar_reserva_valida_e_persistir(self):
        resposta = self.post(self.dados())
        self.assertEqual(resposta.status_code, 201)
        corpo = resposta.json()
        self.assertEqual(corpo["reserva"]["veiculo"]["codigo"], "VL-01")
        self.assertTrue(resposta["Location"].endswith(f"/api/reservas/{corpo['reserva']['id']}/"))
        salva = Reserva.objects.get(pk=corpo["reserva"]["id"])  # lida do banco
        self.assertEqual(salva.solicitante, "Maria Souza")
        self.assertEqual(salva.horario_retorno, time(10, 0))
        self.assertEqual(salva.passageiros, 3)

    def test_consultar_reserva_e_listar(self):
        reserva = self.criar()
        r = self.client.get(reverse("reservas:api_reserva_detalhe", args=[reserva.pk]))
        self.assertEqual(r.status_code, 200)
        self.assertEqual(r.json()["reserva"]["atividade"], "Reunião externa")
        lista = self.client.get(reverse("reservas:api_reservas")).json()
        self.assertEqual(lista["total"], 1)

    def test_consultar_reserva_inexistente_retorna_404(self):
        r = self.client.get(reverse("reservas:api_reserva_detalhe", args=[9999]))
        self.assertEqual(r.status_code, 404)
        self.assertIn("erro", r.json())

    def test_atualizar_reserva(self):
        reserva = self.criar()
        r = self.put(reserva.pk, self.dados(atividade="Inspeção técnica", passageiros=2))
        self.assertEqual(r.status_code, 200)
        reserva.refresh_from_db()
        self.assertEqual(reserva.atividade, "Inspeção técnica")
        self.assertEqual(reserva.passageiros, 2)

    def test_excluir_reserva(self):
        reserva = self.criar()
        r = self.client.delete(reverse("reservas:api_reserva_detalhe", args=[reserva.pk]))
        self.assertEqual(r.status_code, 204)
        self.assertFalse(Reserva.objects.filter(pk=reserva.pk).exists())

    def test_listar_e_consultar_veiculos(self):
        r = self.client.get(reverse("reservas:api_veiculos"))
        self.assertEqual(r.json()["total"], 10)
        vc = Veiculo.objects.get(codigo="VC-01")
        d = self.client.get(reverse("reservas:api_veiculo_detalhe", args=[vc.pk])).json()
        self.assertEqual(d["veiculo"]["capacidade"], 18)
        self.assertEqual(self.client.get(reverse("reservas:api_veiculo_detalhe", args=[9999])).status_code, 404)

    def test_metodo_nao_permitido(self):
        r = self.client.delete(reverse("reservas:api_reservas"))
        self.assertEqual(r.status_code, 405)

    def test_filtros_por_data_e_veiculo(self):
        self.criar(veiculo="VL-01")
        self.criar(veiculo="VL-02")
        self.criar(veiculo="VL-01", data=dias_a_frente(8).isoformat())
        url = reverse("reservas:api_reservas")
        self.assertEqual(self.client.get(url, {"veiculo": "VL-01"}).json()["total"], 2)
        self.assertEqual(self.client.get(url, {"data": dias_a_frente().isoformat()}).json()["total"], 2)
        self.assertEqual(self.client.get(url, {"data": dias_a_frente().isoformat(), "veiculo": "VL-02"}).json()["total"], 1)
        self.assertEqual(self.client.get(url, {"veiculo": "XX-99"}).status_code, 400)


# ---------------------------------------------------------------- capacidade
class CapacidadeTests(BaseTestCase):
    def test_veiculo_leve_aceita_quatro(self):
        self.criar(passageiros=4)

    def test_capacidade_excedida_em_veiculo_leve(self):
        r = self.post(self.dados(passageiros=7))
        self.assertEqual(r.status_code, 400)
        self.assertIn("comporta no máximo 4", r.json()["erros"]["passageiros"][0])
        self.assertEqual(Reserva.objects.count(), 0)

    def test_coletivo_aceita_dezoito(self):
        self.criar(veiculo="VC-01", passageiros=18)

    def test_acima_de_dezoito_e_rejeitado_mesmo_no_coletivo(self):
        r = self.post(self.dados(veiculo="VC-01", passageiros=19))
        self.assertEqual(r.status_code, 400)
        self.assertIn("capacidade máxima da frota", r.json()["erros"]["passageiros"][0])

    def test_passageiros_zero_ou_negativo(self):
        for valor in (0, -3):
            r = self.post(self.dados(passageiros=valor))
            self.assertEqual(r.status_code, 400, valor)
            self.assertIn("pelo menos 1", r.json()["erros"]["passageiros"][0])

    def test_passageiros_com_tipo_invalido(self):
        r = self.post(self.dados(passageiros="abc"))
        self.assertEqual(r.status_code, 400)
        self.assertIn("número inteiro", r.json()["erros"]["passageiros"][0])


# ---------------------------------------------------------------- data e horários
class DataEHorarioTests(BaseTestCase):
    def test_data_passada_e_rejeitada(self):
        ontem = (timezone.localdate() - timedelta(days=1)).isoformat()
        r = self.post(self.dados(data=ontem))
        self.assertEqual(r.status_code, 400)
        self.assertIn("já passou", r.json()["erros"]["data"][0])

    def test_data_de_hoje_e_aceita(self):
        self.criar(data=timezone.localdate().isoformat())

    def test_data_em_formato_brasileiro_e_aceita(self):
        data = dias_a_frente(10)
        self.criar(data=data.strftime("%d/%m/%Y"))

    def test_data_invalida(self):
        r = self.post(self.dados(data="31/02/2030"))
        self.assertEqual(r.status_code, 400)
        self.assertIn("data", r.json()["erros"])

    def test_retorno_antes_da_saida(self):
        r = self.post(self.dados(horario_saida="10:00", horario_retorno="09:00"))
        self.assertEqual(r.status_code, 400)
        self.assertIn("posterior", r.json()["erros"]["horario_retorno"][0])

    def test_retorno_igual_a_saida(self):
        r = self.post(self.dados(horario_saida="10:00", horario_retorno="10:00"))
        self.assertEqual(r.status_code, 400)

    def test_horario_com_formato_invalido(self):
        r = self.post(self.dados(horario_saida="25:99"))
        self.assertEqual(r.status_code, 400)
        self.assertIn("horario_saida", r.json()["erros"])


# ---------------------------------------------------------------- conflitos
class ConflitoTests(BaseTestCase):
    def setUp(self):
        super().setUp()
        self.existente = self.criar(horario_saida="08:00", horario_retorno="10:00")

    def test_conflito_parcial(self):
        r = self.post(self.dados(horario_saida="09:00", horario_retorno="11:00"))
        self.assertEqual(r.status_code, 400)
        self.assertIn("Conflito de horário", r.json()["erros"]["geral"][0])
        self.assertEqual(Reserva.objects.count(), 1)

    def test_conflito_por_intervalo_contido(self):
        r = self.post(self.dados(horario_saida="08:30", horario_retorno="09:30"))
        self.assertEqual(r.status_code, 400)
        self.assertIn("geral", r.json()["erros"])

    def test_conflito_por_intervalo_que_envolve_o_existente(self):
        r = self.post(self.dados(horario_saida="07:00", horario_retorno="11:00"))
        self.assertEqual(r.status_code, 400)

    def test_sem_conflito_depois_do_intervalo(self):
        self.criar(horario_saida="10:30", horario_retorno="12:00")

    def test_limite_exato_nao_e_conflito(self):
        # Retorno às 10:00 e nova saída às 10:00: decisão adotada = permitido.
        self.criar(horario_saida="10:00", horario_retorno="12:00")
        self.criar(horario_saida="06:00", horario_retorno="08:00")

    def test_mesmo_horario_em_outro_veiculo_ou_outra_data(self):
        self.criar(veiculo="VL-02")
        self.criar(data=dias_a_frente(8).isoformat())

    def test_atualizacao_que_provoca_conflito(self):
        outra = self.criar(horario_saida="10:00", horario_retorno="12:00")
        r = self.put(outra.pk, self.dados(horario_saida="09:00", horario_retorno="12:00"))
        self.assertEqual(r.status_code, 400)
        outra.refresh_from_db()
        self.assertEqual(outra.horario_saida, time(10, 0))  # nada foi alterado

    def test_atualizacao_sem_conflito(self):
        outra = self.criar(horario_saida="10:00", horario_retorno="12:00")
        r = self.put(outra.pk, self.dados(horario_saida="11:00", horario_retorno="13:00"))
        self.assertEqual(r.status_code, 200)

    def test_edicao_ignora_a_propria_reserva(self):
        # Mantém exatamente o mesmo horário; só muda a atividade.
        r = self.put(self.existente.pk, self.dados(atividade="Outra atividade"))
        self.assertEqual(r.status_code, 200)

    def test_veiculo_fora_de_operacao_nao_aceita_reserva(self):
        Veiculo.objects.filter(codigo="VL-05").update(disponivel=False)
        r = self.post(self.dados(veiculo="VL-05"))
        self.assertEqual(r.status_code, 400)
        self.assertIn("veiculo", r.json()["erros"])


# ---------------------------------------------------------------- campos obrigatórios
class ValidacaoDeCamposTests(BaseTestCase):
    def test_campos_obrigatorios_ausentes(self):
        campos = ["solicitante", "setor", "atividade", "origem", "destino", "data",
                  "horario_saida", "horario_retorno", "passageiros", "veiculo"]
        for campo in campos:
            r = self.post(self.dados(**{campo: ...}))
            self.assertEqual(r.status_code, 400, campo)
            self.assertIn(campo, r.json()["erros"])

    def test_corpo_vazio(self):
        r = self.post({})
        self.assertEqual(r.status_code, 400)
        self.assertGreaterEqual(len(r.json()["erros"]), 10)

    def test_veiculo_inexistente(self):
        r = self.post(self.dados(veiculo="VL-99"))
        self.assertEqual(r.status_code, 400)
        self.assertIn("inexistente", r.json()["erros"]["veiculo"][0])

    def test_json_invalido(self):
        r = self.client.post(reverse("reservas:api_reservas"), "{nao e json", content_type="application/json")
        self.assertEqual(r.status_code, 400)

    def test_edicao_de_reserva_historica_sem_mudar_a_data(self):
        call_command("carregar_dados", verbosity=0)
        hist = Reserva.objects.get(veiculo__codigo="VL-01")
        dados = self.dados(data="2026-08-18", horario_saida="08:00", horario_retorno="10:00",
                           observacoes="Corrigido")
        self.assertEqual(self.put(hist.pk, dados).status_code, 200)
        novo = self.dados(data="2026-08-17", horario_saida="08:00", horario_retorno="10:00")
        self.assertEqual(self.put(hist.pk, novo).status_code, 400)  # mudar para outra data passada


# ---------------------------------------------------------------- disponibilidade
class DisponibilidadeTests(BaseTestCase):
    def consultar(self, **params):
        base = {"data": dias_a_frente().isoformat(), "saida": "09:00", "retorno": "11:00"}
        base.update(params)
        return self.client.get(reverse("reservas:api_disponibilidade"), base)

    def test_todos_livres_sem_reservas(self):
        corpo = self.consultar().json()
        self.assertEqual(len(corpo["disponiveis"]), 10)
        self.assertEqual(corpo["indisponiveis"], [])

    def test_veiculo_reservado_fica_indisponivel(self):
        self.criar(horario_saida="08:00", horario_retorno="10:00")
        corpo = self.consultar().json()
        self.assertEqual(len(corpo["disponiveis"]), 9)
        self.assertEqual(corpo["indisponiveis"][0]["veiculo"]["codigo"], "VL-01")
        self.assertIn("Reservado das 08:00 às 10:00", corpo["indisponiveis"][0]["motivo"])

    def test_intervalo_encostado_deixa_veiculo_disponivel(self):
        self.criar(horario_saida="08:00", horario_retorno="10:00")
        corpo = self.consultar(saida="10:00", retorno="12:00").json()
        self.assertEqual(len(corpo["disponiveis"]), 10)

    def test_filtro_por_quantidade_de_passageiros(self):
        corpo = self.consultar(passageiros=10).json()
        self.assertEqual({v["codigo"] for v in corpo["disponiveis"]}, {"VC-01", "VC-02"})
        self.assertEqual(len(corpo["indisponiveis"]), 8)

    def test_parametros_invalidos(self):
        r = self.client.get(reverse("reservas:api_disponibilidade"), {"data": dias_a_frente().isoformat()})
        self.assertEqual(r.status_code, 400)
        self.assertIn("saida", r.json()["erros"])
        self.assertEqual(self.consultar(saida="12:00", retorno="11:00").status_code, 400)
        self.assertEqual(self.consultar(passageiros=30).status_code, 400)


# ---------------------------------------------------------------- CSRF e telas
class CsrfTests(BaseTestCase):
    def test_post_sem_token_csrf_e_bloqueado(self):
        cliente = Client(enforce_csrf_checks=True)
        r = self.post(self.dados(), client=cliente)
        self.assertEqual(r.status_code, 403)
        self.assertIn("CSRF", r.json()["erro"])
        self.assertEqual(Reserva.objects.count(), 0)

    def test_post_com_token_csrf_funciona(self):
        cliente = Client(enforce_csrf_checks=True)
        token = cliente.get(reverse("reservas:api_csrf")).json()["csrfToken"]
        r = cliente.post(reverse("reservas:api_reservas"), json.dumps(self.dados()),
                         content_type="application/json", headers={"X-CSRFToken": token})
        self.assertEqual(r.status_code, 201)


class TelasTests(BaseTestCase):
    def test_paginas_abrem(self):
        for nome in ("home", "veiculos", "reservas", "reserva_criar", "disponibilidade"):
            self.assertEqual(self.client.get(reverse(f"reservas:{nome}")).status_code, 200, nome)

    def test_formulario_cria_reserva_e_mostra_sucesso(self):
        r = self.client.post(reverse("reservas:reserva_criar"), self.dados(), follow=True)
        self.assertContains(r, "Reserva registrada")
        self.assertEqual(Reserva.objects.count(), 1)

    def test_formulario_mostra_mensagem_de_conflito(self):
        self.criar()
        r = self.client.post(reverse("reservas:reserva_criar"), self.dados(horario_saida="09:00", horario_retorno="11:00"))
        self.assertContains(r, "Conflito de horário")
        self.assertEqual(Reserva.objects.count(), 1)

    def test_editar_e_excluir_pela_tela(self):
        reserva = self.criar()
        r = self.client.post(reverse("reservas:reserva_editar", args=[reserva.pk]), self.dados(atividade="Nova"), follow=True)
        self.assertContains(r, "atualizada")
        r = self.client.post(reverse("reservas:reserva_excluir", args=[reserva.pk]), follow=True)
        self.assertContains(r, "excluída")
        self.assertEqual(Reserva.objects.count(), 0)

    def test_tela_de_disponibilidade(self):
        self.criar()
        r = self.client.get(reverse("reservas:disponibilidade"),
                            {"data": dias_a_frente().isoformat(), "saida": "09:00", "retorno": "11:00"})
        self.assertContains(r, "Reservado das 08:00 às 10:00")
