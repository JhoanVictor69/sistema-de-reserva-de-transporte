from django import forms

from .models import Reserva, Veiculo
from .regras import CAPACIDADE_MAXIMA_FROTA


class VeiculoChoiceField(forms.ModelChoiceField):
    """Campo de veículo: o valor enviado é o código (ex.: VL-01), não o id numérico."""

    def label_from_instance(self, veiculo):
        return str(veiculo)


def campo_veiculo(**kwargs):
    return VeiculoChoiceField(
        queryset=Veiculo.objects.all(),
        to_field_name="codigo",
        empty_label="Selecione um veículo",
        error_messages={
            "required": "Informe o veículo.",
            "invalid_choice": "Veículo inexistente. Informe um código cadastrado (ex.: VL-01 ou VC-01).",
        },
        **kwargs,
    )


class ReservaForm(forms.ModelForm):
    """Valida os dados de uma reserva. É usado pelas telas e pela API.

    Esta classe cuida de campos obrigatórios e tipos; as regras de negócio
    (capacidade, data, horários, conflito) ficam em Reserva.clean() / regras.py.
    """

    veiculo = campo_veiculo()
    passageiros = forms.IntegerField(
        label="Quantidade de passageiros",
        error_messages={
            "required": "Informe a quantidade de passageiros.",
            "invalid": "A quantidade de passageiros deve ser um número inteiro.",
        },
    )

    class Meta:
        model = Reserva
        fields = [
            "solicitante", "setor", "atividade", "origem", "destino", "data",
            "horario_saida", "horario_retorno", "passageiros", "veiculo", "observacoes",
        ]
        widgets = {
            "data": forms.DateInput(attrs={"type": "date"}, format="%Y-%m-%d"),
            "horario_saida": forms.TimeInput(attrs={"type": "time"}, format="%H:%M"),
            "horario_retorno": forms.TimeInput(attrs={"type": "time"}, format="%H:%M"),
            "observacoes": forms.Textarea(attrs={"rows": 3}),
        }

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for nome, campo in self.fields.items():
            if nome not in ("passageiros", "veiculo"):  # esses dois já têm mensagem própria
                campo.error_messages["required"] = f"O campo {campo.label.lower()} é obrigatório."
        self.fields["data"].error_messages["invalid"] = "Data inválida. Use o formato AAAA-MM-DD ou DD/MM/AAAA."
        for nome in ("horario_saida", "horario_retorno"):
            self.fields[nome].error_messages["invalid"] = "Horário inválido. Use o formato HH:MM."


class FiltroReservasForm(forms.Form):
    """Filtros opcionais da lista de reservas (tela e API)."""

    data = forms.DateField(required=False, label="Data")
    veiculo = VeiculoChoiceField(
        queryset=Veiculo.objects.all(),
        to_field_name="codigo",
        required=False,
        empty_label="Todos os veículos",
        label="Veículo",
        error_messages={"invalid_choice": "Veículo inexistente."},
    )


class DisponibilidadeForm(forms.Form):
    """Parâmetros da consulta de disponibilidade."""

    data = forms.DateField(label="Data", error_messages={"required": "Informe a data.", "invalid": "Data inválida."})
    saida = forms.TimeField(
        label="Saída",
        widget=forms.TimeInput(attrs={"type": "time"}, format="%H:%M"),
        error_messages={"required": "Informe o horário de saída.", "invalid": "Horário inválido (HH:MM)."},
    )
    retorno = forms.TimeField(
        label="Retorno",
        widget=forms.TimeInput(attrs={"type": "time"}, format="%H:%M"),
        error_messages={"required": "Informe o horário de retorno.", "invalid": "Horário inválido (HH:MM)."},
    )
    passageiros = forms.IntegerField(
        required=False,
        label="Passageiros (opcional)",
        min_value=1,
        max_value=CAPACIDADE_MAXIMA_FROTA,
        error_messages={
            "invalid": "Informe um número inteiro.",
            "min_value": "A quantidade de passageiros deve ser de pelo menos 1.",
            "max_value": f"Nenhum veículo comporta mais de {CAPACIDADE_MAXIMA_FROTA} passageiros.",
        },
    )

    def clean(self):
        dados = super().clean()
        saida, retorno = dados.get("saida"), dados.get("retorno")
        if saida and retorno and retorno <= saida:
            self.add_error("retorno", "O horário de retorno deve ser posterior ao horário de saída.")
        return dados
