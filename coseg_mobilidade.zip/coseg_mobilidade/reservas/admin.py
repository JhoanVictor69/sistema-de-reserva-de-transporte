from django.contrib import admin

from .models import Reserva, Veiculo


@admin.register(Veiculo)
class VeiculoAdmin(admin.ModelAdmin):
    list_display = ("codigo", "categoria", "capacidade", "disponivel")
    list_filter = ("categoria", "disponivel")
    search_fields = ("codigo",)


@admin.register(Reserva)
class ReservaAdmin(admin.ModelAdmin):
    list_display = ("veiculo", "data", "horario_saida", "horario_retorno", "atividade", "solicitante", "passageiros")
    list_filter = ("veiculo", "data")
    search_fields = ("solicitante", "setor", "atividade")
