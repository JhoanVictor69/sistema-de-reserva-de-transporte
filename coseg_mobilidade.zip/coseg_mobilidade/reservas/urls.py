from django.urls import path

from . import api, views

app_name = "reservas"

urlpatterns = [
    # Telas
    path("", views.home, name="home"),
    path("veiculos/", views.veiculos_lista, name="veiculos"),
    path("reservas/", views.reservas_lista, name="reservas"),
    path("reservas/nova/", views.reserva_criar, name="reserva_criar"),
    path("reservas/<int:pk>/editar/", views.reserva_editar, name="reserva_editar"),
    path("reservas/<int:pk>/excluir/", views.reserva_excluir, name="reserva_excluir"),
    path("disponibilidade/", views.disponibilidade, name="disponibilidade"),
    # API JSON
    path("api/csrf/", api.csrf, name="api_csrf"),
    path("api/veiculos/", api.veiculos, name="api_veiculos"),
    path("api/veiculos/<int:pk>/", api.veiculo_detalhe, name="api_veiculo_detalhe"),
    path("api/reservas/", api.reservas, name="api_reservas"),
    path("api/reservas/<int:pk>/", api.reserva_detalhe, name="api_reserva_detalhe"),
    path("api/disponibilidade/", api.disponibilidade, name="api_disponibilidade"),
]
