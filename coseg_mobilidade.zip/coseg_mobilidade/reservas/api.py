"""Endpoints JSON consumidos por clientes externos (e, futuramente, pela interface do PBL 2).

Padrão das respostas:
    sucesso -> {"mensagem": "...", "reserva": {...}}  ou  {"total": n, "reservas": [...]}
    erro    -> {"erro": "resumo", "erros": {"campo": ["mensagem", ...]}}
A proteção CSRF do Django continua ativa (ver README, seção "Testando a API").
"""
import json

from django.http import HttpResponse, JsonResponse
from django.middleware.csrf import get_token
from django.views.decorators.csrf import ensure_csrf_cookie

from . import regras
from .forms import DisponibilidadeForm, FiltroReservasForm, ReservaForm
from .models import Reserva, Veiculo


# ------------------------------------------------------------------ utilidades
def _json(dados, status=200):
    return JsonResponse(dados, status=status, json_dumps_params={"ensure_ascii": False})


def _erro(mensagem, status, erros=None):
    corpo = {"erro": mensagem}
    if erros:
        corpo["erros"] = erros
    return _json(corpo, status)


def _erros_do_form(form):
    erros = {}
    for campo, lista in form.errors.items():
        nome = "geral" if campo == "__all__" else campo
        erros[nome] = [str(e) for e in lista]
    return _erro("Dados inválidos. Nenhuma alteração foi gravada.", 400, erros)


def _metodo_nao_permitido(permitidos):
    resposta = _erro(f"Método não permitido. Use: {', '.join(permitidos)}.", 405)
    resposta["Allow"] = ", ".join(permitidos)
    return resposta


def _ler_json(request):
    try:
        dados = json.loads(request.body.decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        return None, _erro("Corpo da requisição inválido: envie um JSON válido.", 400)
    if not isinstance(dados, dict):
        return None, _erro("O corpo da requisição deve ser um objeto JSON.", 400)
    return dados, None


def veiculo_para_dict(veiculo):
    return {
        "id": veiculo.pk,
        "codigo": veiculo.codigo,
        "categoria": veiculo.get_categoria_display(),
        "capacidade": veiculo.capacidade,
        "disponivel": veiculo.disponivel,
    }


def reserva_para_dict(reserva):
    return {
        "id": reserva.pk,
        "solicitante": reserva.solicitante,
        "setor": reserva.setor,
        "atividade": reserva.atividade,
        "origem": reserva.origem,
        "destino": reserva.destino,
        "data": reserva.data.isoformat(),
        "horario_saida": reserva.horario_saida.strftime("%H:%M"),
        "horario_retorno": reserva.horario_retorno.strftime("%H:%M"),
        "passageiros": reserva.passageiros,
        "veiculo": veiculo_para_dict(reserva.veiculo),
        "observacoes": reserva.observacoes,
    }


# ------------------------------------------------------------------ endpoints
@ensure_csrf_cookie
def csrf(request):
    """GET /api/csrf/ -> grava o cookie csrftoken e devolve o token para o cabeçalho X-CSRFToken."""
    return _json({"csrfToken": get_token(request)})


def veiculos(request):
    if request.method != "GET":
        return _metodo_nao_permitido(["GET"])
    lista = [veiculo_para_dict(v) for v in Veiculo.objects.all()]
    return _json({"total": len(lista), "veiculos": lista})


def veiculo_detalhe(request, pk):
    if request.method != "GET":
        return _metodo_nao_permitido(["GET"])
    try:
        veiculo = Veiculo.objects.get(pk=pk)
    except Veiculo.DoesNotExist:
        return _erro("Veículo não encontrado.", 404)
    return _json({"veiculo": veiculo_para_dict(veiculo)})


def reservas(request):
    if request.method == "GET":
        filtro = FiltroReservasForm(request.GET)
        if not filtro.is_valid():
            return _erros_do_form(filtro)
        lista = Reserva.objects.select_related("veiculo")
        if filtro.cleaned_data["data"]:
            lista = lista.filter(data=filtro.cleaned_data["data"])
        if filtro.cleaned_data["veiculo"]:
            lista = lista.filter(veiculo=filtro.cleaned_data["veiculo"])
        itens = [reserva_para_dict(r) for r in lista]
        return _json({"total": len(itens), "reservas": itens})

    if request.method == "POST":
        dados, erro = _ler_json(request)
        if erro:
            return erro
        form = ReservaForm(dados)
        if not form.is_valid():
            return _erros_do_form(form)
        reserva = form.save()
        resposta = _json({"mensagem": "Reserva registrada com sucesso.", "reserva": reserva_para_dict(reserva)}, 201)
        resposta["Location"] = f"/api/reservas/{reserva.pk}/"
        return resposta

    return _metodo_nao_permitido(["GET", "POST"])


def reserva_detalhe(request, pk):
    try:
        reserva = Reserva.objects.select_related("veiculo").get(pk=pk)
    except Reserva.DoesNotExist:
        return _erro("Reserva não encontrada.", 404)

    if request.method == "GET":
        return _json({"reserva": reserva_para_dict(reserva)})

    if request.method == "PUT":
        dados, erro = _ler_json(request)
        if erro:
            return erro
        form = ReservaForm(dados, instance=reserva)
        if not form.is_valid():
            return _erros_do_form(form)
        reserva = form.save()
        return _json({"mensagem": "Reserva atualizada com sucesso.", "reserva": reserva_para_dict(reserva)})

    if request.method == "DELETE":
        reserva.delete()
        return HttpResponse(status=204)

    return _metodo_nao_permitido(["GET", "PUT", "DELETE"])


def disponibilidade(request):
    """GET /api/disponibilidade/?data=AAAA-MM-DD&saida=HH:MM&retorno=HH:MM[&passageiros=N]"""
    if request.method != "GET":
        return _metodo_nao_permitido(["GET"])
    form = DisponibilidadeForm(request.GET)
    if not form.is_valid():
        return _erros_do_form(form)
    d = form.cleaned_data
    livres, ocupados = regras.consultar_disponibilidade(d["data"], d["saida"], d["retorno"], d["passageiros"])
    return _json(
        {
            "consulta": {
                "data": d["data"].isoformat(),
                "saida": d["saida"].strftime("%H:%M"),
                "retorno": d["retorno"].strftime("%H:%M"),
                "passageiros": d["passageiros"],
            },
            "disponiveis": [veiculo_para_dict(v) for v in livres],
            "indisponiveis": [{"veiculo": veiculo_para_dict(v), "motivo": m} for v, m in ocupados],
        }
    )
