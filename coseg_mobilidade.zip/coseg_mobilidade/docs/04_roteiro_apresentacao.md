# Roteiro de apresentação (5 a 7 minutos)

Sugestão de divisão para quatro integrantes; ajustem conforme a equipe. Tempo total aproximado: 6 min 30 s.

## 1. Problema identificado (0:45) — Integrante 1
"O COSEG controla dez veículos, mas os pedidos chegam por telefone, mensagem, e-mail e planilhas. Sem um registro único, aconteceu de dois setores esperarem o mesmo carro, de um carro de quatro lugares ser pedido para sete pessoas e de um veículo ser reservado antes de voltar da atividade anterior. O problema não é só registrar a saída: é controlar todo o intervalo de uso."

## 2. Objetivo do sistema (0:30) — Integrante 1
"Nesta etapa, construímos a camada de servidor: o servidor guarda as reservas em banco de dados e recusa o que for inconsistente, antes de gravar. Ele oferece uma API para a interface do PBL 2."

## 3. Estrutura do projeto (0:45) — Integrante 2
Mostrar a árvore no VS Code: `config/` (configurações), `reservas/` (app). "O `models.py` define as tabelas, o `regras.py` concentra as regras de negócio, o `forms.py` valida campos e tipos, `views.py` e `api.py` respondem às requisições, e o `tests.py` verifica tudo. O comando `carregar_dados` cadastra a frota e os dados do enunciado."

## 4. Modelagem do banco (0:45) — Integrante 2
Mostrar `models.py`. "Duas tabelas: `Veiculo` (código, categoria, capacidade, em operação) e `Reserva` (solicitante, setor, atividade, origem, destino, data, saída, retorno, passageiros, observações). A reserva aponta para um veículo por chave estrangeira. As migrations criam essas tabelas no SQLite."

## 5. Regras de negócio (1:00) — Integrante 3
Mostrar `regras.py`. "Capacidade: quatro para leves, dezoito para coletivos; acima de dezoito é rejeitado. Data: não pode ser anterior a hoje, usando o fuso de São Luís. Horário: retorno depois da saída. Conflito: consulta no banco por reservas do mesmo veículo e data em que `saída < retorno existente` e `retorno > saída existente`. Decidimos que uma reserva que termina às 10h e outra que começa às 10h não conflitam."

## 6. Demonstração do CRUD (1:00) — Integrante 3
No navegador: `/veiculos/` (10 veículos) → `/reservas/` (dados do enunciado em cinza, pois são de agosto) → *Nova reserva* com data futura, VL-01, 08h–10h, 3 passageiros → mensagem de sucesso → editar a atividade → excluir. Opcional: mostrar `GET /api/reservas/` no navegador.

## 7. Demonstração do conflito (0:45) — Integrante 4
Com a reserva VL-01 08h–10h criada, tentar nova reserva VL-01 09h–11h: mostrar a mensagem de conflito e que nada foi gravado. Depois: 7 passageiros no VL-01 (capacidade), data de ontem (data passada) e `/disponibilidade/` mostrando VL-01 indisponível naquele horário e os demais livres.

## 8. Testes (0:30) — Integrante 4
Rodar `manage.py test` no terminal. "São 52 testes: persistência, CRUD, capacidade, datas, horários, conflitos, disponibilidade e CSRF." Falar o resultado exato que aparecer na tela (número de testes e OK/FAILED).

## 9. Conclusão (0:30) — Integrante 1
"O servidor agora é a fonte única das reservas: os dados persistem, as regras são aplicadas antes de gravar e a API está pronta para a interface do PBL 2. Como limitações, ainda não há login de usuários e, em uso real, seria preciso tratar acessos simultâneos."

## Preparação antes de apresentar
1. `migrate` e `carregar_dados` executados; servidor rodando.
2. Anotar uma data futura para usar na demonstração (ex.: a de daqui a 7 dias).
3. Reservas de teste da demonstração apagadas antes, para começar limpo.
4. Terminal com os testes já aberto em outra aba.
