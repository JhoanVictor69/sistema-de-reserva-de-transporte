# Evidências de testes

Os testes automatizados ficam em `reservas/tests.py`. Para executar:

```powershell
.\.venv\Scripts\python.exe manage.py test
.\.venv\Scripts\python.exe manage.py test -v 2     # lista cada teste
.\.venv\Scripts\python.exe manage.py test reservas.tests.ConflitoTests   # só uma classe
```

A coluna **Resultado real** deve ser preenchida pela equipe após executar o comando no próprio computador. Capturas de tela devem ser feitas por vocês; este documento não traz imagens nem resultados prontos.

## 1. Persistência, frota e CRUD

| Cenário | Entrada | Resultado esperado | Teste automatizado | Resultado real |
|---|---|---|---|---|
| Cadastro dos 10 veículos | `carregar_dados` | 10 veículos: 8 leves (4 lugares) e 2 coletivos (18) | `FrotaEComandoTests.test_comando_cadastra_dez_veiculos` | |
| Reservas do enunciado | `carregar_dados` | 4 reservas com veículo, data e horários do enunciado | `test_comando_cadastra_reservas_do_enunciado` | |
| Comando repetido | `carregar_dados` duas vezes | Continua com 10 veículos e 4 reservas | `test_comando_e_repetivel_sem_duplicar` | |
| Criar reserva válida | POST com dados válidos | 201 e registro lido do banco com os mesmos dados | `CrudTests.test_criar_reserva_valida_e_persistir` | |
| Consultar reserva | GET `/api/reservas/<id>/` | 200 com os dados | `test_consultar_reserva_e_listar` | |
| Consultar inexistente | GET id 9999 | 404 | `test_consultar_reserva_inexistente_retorna_404` | |
| Atualizar reserva | PUT com novos dados | 200 e banco atualizado | `test_atualizar_reserva` | |
| Excluir reserva | DELETE | 204 e registro removido | `test_excluir_reserva` | |
| Listar/consultar veículos | GET `/api/veiculos/` | 10 veículos; 404 para id inexistente | `test_listar_e_consultar_veiculos` | |
| Filtros | `?data=` e `?veiculo=` | Apenas reservas correspondentes | `test_filtros_por_data_e_veiculo` | |

## 2. Capacidade

| Cenário | Entrada | Resultado esperado | Teste | Resultado real |
|---|---|---|---|---|
| Leve com 4 | VL-01, 4 passageiros | Aceita | `CapacidadeTests.test_veiculo_leve_aceita_quatro` | |
| Leve com 7 | VL-01, 7 passageiros | 400, mensagem de capacidade, nada gravado | `test_capacidade_excedida_em_veiculo_leve` | |
| Coletivo com 18 | VC-01, 18 | Aceita | `test_coletivo_aceita_dezoito` | |
| Acima de 18 | VC-01, 19 | 400 (excede a frota) | `test_acima_de_dezoito_e_rejeitado_mesmo_no_coletivo` | |
| Zero/negativo | 0 e -3 | 400 ("pelo menos 1") | `test_passageiros_zero_ou_negativo` | |
| Tipo inválido | "abc" | 400 ("número inteiro") | `test_passageiros_com_tipo_invalido` | |

## 3. Data e horários

| Cenário | Entrada | Resultado esperado | Teste | Resultado real |
|---|---|---|---|---|
| Data passada | ontem | 400 no campo `data` | `DataEHorarioTests.test_data_passada_e_rejeitada` | |
| Data de hoje | hoje | Aceita | `test_data_de_hoje_e_aceita` | |
| Formato DD/MM/AAAA | data futura | Aceita | `test_data_em_formato_brasileiro_e_aceita` | |
| Data inválida | 31/02/2030 | 400 | `test_data_invalida` | |
| Retorno antes da saída | 10:00 → 09:00 | 400 | `test_retorno_antes_da_saida` | |
| Retorno igual à saída | 10:00 → 10:00 | 400 | `test_retorno_igual_a_saida` | |
| Horário inválido | 25:99 | 400 | `test_horario_com_formato_invalido` | |
| Dados históricos x data passada | nova reserva no passado após `carregar_dados` | Continua rejeitada | `test_dados_historicos_nao_liberam_novas_reservas_no_passado` | |
| Editar reserva histórica | mesma data / outra data passada | 200 / 400 | `test_edicao_de_reserva_historica_sem_mudar_a_data` | |

## 4. Conflito de horários

Reserva existente: VL-01, 08:00–10:00.

| Cenário | Nova reserva | Resultado esperado | Teste | Resultado real |
|---|---|---|---|---|
| Conflito parcial | 09:00–11:00 | 400 (conflito) | `ConflitoTests.test_conflito_parcial` | |
| Intervalo contido | 08:30–09:30 | 400 | `test_conflito_por_intervalo_contido` | |
| Intervalo que envolve | 07:00–11:00 | 400 | `test_conflito_por_intervalo_que_envolve_o_existente` | |
| Sem conflito | 10:30–12:00 | 201 | `test_sem_conflito_depois_do_intervalo` | |
| Limite exato | 10:00–12:00 e 06:00–08:00 | 201 (encostado não conflita) | `test_limite_exato_nao_e_conflito` | |
| Outro veículo / outra data | mesmo horário | 201 | `test_mesmo_horario_em_outro_veiculo_ou_outra_data` | |
| Atualização com conflito | mover reserva 10–12 para 09–12 | 400, banco inalterado | `test_atualizacao_que_provoca_conflito` | |
| Atualização sem conflito | mover para 11–13 | 200 | `test_atualizacao_sem_conflito` | |
| Edição da própria reserva | mesmo horário, outra atividade | 200 | `test_edicao_ignora_a_propria_reserva` | |
| Veículo fora de operação | VL-05 inativo | 400 | `test_veiculo_fora_de_operacao_nao_aceita_reserva` | |

## 5. Campos obrigatórios e veículo

| Cenário | Entrada | Resultado esperado | Teste | Resultado real |
|---|---|---|---|---|
| Campo ausente | cada um dos 10 campos obrigatórios removido | 400 com erro no campo | `ValidacaoDeCamposTests.test_campos_obrigatorios_ausentes` | |
| Corpo vazio | `{}` | 400 com 10 ou mais erros | `test_corpo_vazio` | |
| Veículo inexistente | `VL-99` | 400 ("Veículo inexistente") | `test_veiculo_inexistente` | |
| JSON inválido | texto não JSON | 400 | `test_json_invalido` | |

## 6. Disponibilidade, CSRF e telas

| Cenário | Resultado esperado | Teste | Resultado real |
|---|---|---|---|
| Sem reservas | 10 disponíveis | `DisponibilidadeTests.test_todos_livres_sem_reservas` | |
| Veículo reservado | VL-01 indisponível com motivo, 9 disponíveis | `test_veiculo_reservado_fica_indisponivel` | |
| Intervalo encostado | VL-01 continua disponível | `test_intervalo_encostado_deixa_veiculo_disponivel` | |
| 10 passageiros | só VC-01 e VC-02 disponíveis | `test_filtro_por_quantidade_de_passageiros` | |
| Parâmetros inválidos | 400 | `test_parametros_invalidos` | |
| POST sem token CSRF | 403 em JSON | `CsrfTests.test_post_sem_token_csrf_e_bloqueado` | |
| POST com token CSRF | 201 | `test_post_com_token_csrf_funciona` | |
| Telas | páginas abrem; formulário cria, edita, exclui e mostra conflito | `TelasTests.*` | |

## 7. Registro da execução (preencher)

- Data e hora da execução: ______________________
- Comando: `manage.py test`
- Saída final (copiar): `Ran __ tests in __s  —  OK / FAILED`
- Capturas de tela anexadas (opcional): terminal com os testes; tela de reservas; mensagem de conflito no formulário.
