# Guia de estudo do código

## 1. Arquivos principais

| Arquivo | Para que serve |
|---|---|
| `config/settings.py` | Configurações: app `reservas`, SQLite, idioma `pt-br`, fuso `America/Fortaleza`, pastas `templates` e `static`. |
| `config/urls.py` | Entrada das rotas: `/admin/` e as rotas do app. |
| `reservas/models.py` | Tabelas `Veiculo` e `Reserva`. `Reserva.clean()` chama as regras. |
| `reservas/regras.py` | Uma função por regra de negócio + `consultar_disponibilidade`. |
| `reservas/forms.py` | `ReservaForm` (campos obrigatórios, tipos, veículo por código), filtros e consulta de disponibilidade. |
| `reservas/views.py` | Telas HTML (listar, criar, editar, excluir, disponibilidade). |
| `reservas/api.py` | Endpoints JSON. |
| `reservas/urls.py` | Liga cada rota a uma view. |
| `reservas/management/commands/carregar_dados.py` | Comando que cadastra frota e dados do enunciado. |
| `reservas/tests.py` | Testes automatizados. |
| `reservas/migrations/0001_initial.py` | Criação das tabelas. |

## 2. Funções mais importantes (em `regras.py`)

- `validar_passageiros(passageiros, veiculo)`: rejeita ≤ 0, > 18 e acima da capacidade do veículo.
- `validar_data(data, data_original)`: rejeita data anterior a `timezone.localdate()`; na edição sem mudança de data, não reaplica.
- `validar_horarios(saida, retorno)`: exige retorno > saída.
- `buscar_conflitos(...)`: consulta ORM com `horario_saida__lt=retorno` e `horario_retorno__gt=saida`; `.exclude(pk=...)` na edição.
- `validar_reserva(reserva)`: junta todas as regras e devolve `{campo: [mensagens]}`.
- `consultar_disponibilidade(...)`: separa veículos livres e indisponíveis, com o motivo.

## 3. Fluxo de uma requisição — `POST /api/reservas/`

1. O navegador/cliente envia JSON com cookie `csrftoken` e cabeçalho `X-CSRFToken`.
2. O `CsrfViewMiddleware` confere o token (se falhar, `falha_csrf` devolve 403 em JSON).
3. `config/urls.py` → `reservas/urls.py` → `api.reservas`.
4. A view lê o JSON (`_ler_json`); se for inválido, responde 400.
5. `ReservaForm(dados)` valida obrigatórios e tipos, e transforma o código do veículo em objeto `Veiculo` (inexistente → erro).
6. O form monta uma `Reserva` e chama `Reserva.clean()`, que executa `regras.validar_reserva` (capacidade, data, horários, veículo em operação e conflito consultando o SQLite).
7. Se houver erro: resposta 400 com `{"erro": ..., "erros": {...}}`; nada é gravado.
8. Se estiver tudo certo: `form.save()` grava no banco e a resposta é 201 com a reserva e o cabeçalho `Location`.

O formulário HTML segue o mesmo caminho, mas a view `reserva_criar` mostra os erros na página em vez de JSON.

## 4. Como alterar com segurança

- Mudar a capacidade ou categoria de um veículo: Django Admin (`/admin/`) ou `carregar_dados`.
- Mudar uma regra: edite a função correspondente em `regras.py` e rode os testes.
- Aceitar reservas encostadas como conflito: troque `__lt`/`__gt` por `__lte`/`__gte` em `buscar_conflitos` e em `consultar_disponibilidade`, e ajuste `test_limite_exato_nao_e_conflito`.
- Novo campo na reserva: altere `Reserva`, o `fields` do `ReservaForm`, `reserva_para_dict` e rode `makemigrations` e `migrate`.

## 5. Perguntas que o professor pode fazer

**Por que validar no servidor se o formulário HTML já valida?**
Porque o HTML pode ser contornado (outro cliente, requisição manual). O servidor é a fonte de verdade; por isso a regra está no model/regras e vale para qualquer origem.

**O que é uma migration?**
É um arquivo que descreve alterações na estrutura do banco. `makemigrations` gera o arquivo a partir dos models; `migrate` aplica no banco.

**Como o conflito de horário é detectado?**
Consulta ao banco: mesmo veículo, mesma data, `saída_existente < nova_retorno` e `retorno_existente > nova_saída`. Se existir algum registro, há sobreposição.

**Por que `<` e `>` e não `<=` e `>=`?**
Com `<=`/`>=`, uma reserva que termina às 10h bloquearia outra que começa às 10h, mesmo com o veículo livre. Adotamos que o encostado é permitido e testamos isso.

**Como a edição não conflita com ela mesma?**
Usamos `.exclude(pk=reserva.pk)` na consulta de conflito.

**Por que as reservas do enunciado não passam pela regra de data?**
Porque são dados históricos (agosto/2026) que podem estar no passado. O comando grava direto pelo ORM; reservas novas sempre passam pela validação.

**Por que usar `timezone.localdate()`?**
Para comparar com a data local (São Luís, UTC-3). Com `date.today()` ou UTC, perto da meia-noite a data poderia estar errada.

**O que é CSRF e por que não foi desativado?**
É um ataque em que um site malicioso faz o navegador do usuário enviar requisições para outro site. O Django exige um token nas requisições que alteram dados. Mantivemos a proteção e criamos `/api/csrf/` para clientes obterem o token.

**Qual é a diferença entre PUT e POST?**
POST cria um recurso novo; PUT substitui os dados de um recurso existente (aqui, a reserva `<id>`, enviando todos os campos).

**Por que `on_delete=PROTECT` na chave estrangeira?**
Para não apagar um veículo que tenha reservas, o que deixaria o histórico inconsistente.

**Por que SQLite?**
Não exige instalação, é o padrão do Django e basta para esta etapa. Em produção usaríamos outro banco, trocando apenas a configuração.

**Que limitações o sistema tem?**
Não há autenticação, não há tratamento especial para requisições simultâneas ao mesmo horário e as reservas não atravessam a meia-noite.

**O que cada camada faz (form, regras, model)?**
O form trata obrigatórios e tipos; `regras.py` implementa as regras de negócio; `Reserva.clean()` liga as regras ao model para valer em telas, API e Admin.
