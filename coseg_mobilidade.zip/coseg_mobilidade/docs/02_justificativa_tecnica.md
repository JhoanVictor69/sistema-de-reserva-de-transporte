# Justificativa técnica

## Problema

O COSEG recebe pedidos de veículos por canais diferentes, sem registro central. Isso levou a veículos reservados em duplicidade, a pedidos acima da capacidade e a conflitos por não considerar o horário de retorno. O servidor precisa ser a fonte única das reservas e impedir essas inconsistências antes de gravar.

## Escolhas técnicas

**Django.** Traz, no mesmo framework, ORM, migrations, formulários com validação, roteamento, painel administrativo e framework de testes. Isso reduz o número de bibliotecas e deixa o projeto na estrutura convencional exigida pela disciplina (projeto + app, models, views, URLs).

**SQLite.** É o banco padrão do Django, fica em um único arquivo (`db.sqlite3`) e não exige instalação. Atende a necessidade de persistência da primeira etapa. Em produção, com muitos usuários simultâneos, seria recomendável um banco servidor (ex.: PostgreSQL); a troca é feita em `DATABASES` sem alterar models.

**Models e ORM.** `Veiculo` e `Reserva` representam as tabelas; a relação é uma `ForeignKey` (um veículo tem muitas reservas). `on_delete=PROTECT` impede apagar um veículo que tenha reservas. A consulta de conflito usa `Reserva.objects.filter(...)`, ou seja, compara com os dados realmente gravados, não com listas temporárias.

**Migrations.** Descrevem a criação das tabelas de forma versionada; `migrate` cria o banco em qualquer máquina.

**Views e URLs.** As rotas de tela (`/reservas/`...) e as de API (`/api/...`) apontam para funções em `views.py` e `api.py`. A API devolve JSON e códigos HTTP adequados (200, 201, 204, 400, 403, 404, 405), pronta para ser consumida pela interface do PBL 2.

**Organização das validações.** Três camadas, cada uma com responsabilidade clara:
1. `forms.py` (`ReservaForm`): campos obrigatórios, tipos e veículo existente;
2. `regras.py`: regras de negócio, uma função por regra;
3. `models.py` (`Reserva.clean()`): chama `regras.py`, de modo que a mesma validação vale para telas, API e Admin.

**CSRF mantido.** A proteção não foi desativada. Clientes externos obtêm o token em `GET /api/csrf/`. Em `/api/`, falhas de CSRF retornam JSON.

**Fuso horário.** `USE_TZ=True` e `TIME_ZONE="America/Fortaleza"`. A data atual vem de `timezone.localdate()`, evitando erro perto da meia-noite (quando a data em UTC já mudou, mas a local não).

## Regra de conflito

```python
Reserva.objects.filter(
    veiculo=veiculo, data=data,
    horario_saida__lt=novo_retorno,
    horario_retorno__gt=nova_saida,
)
```

Duas faixas se sobrepõem quando cada uma começa antes de a outra terminar. Os operadores são estritos (`<` e `>`): se uma reserva termina às 10:00 e a próxima começa às 10:00, o veículo está livre naquele instante e não há conflito. A decisão é testada (`test_limite_exato_nao_e_conflito`). Na edição usa-se `.exclude(pk=...)` para não comparar a reserva com ela mesma.

## Dados históricos x novas reservas

O comando `carregar_dados` grava as reservas do enunciado diretamente com o ORM (sem `clean()`), porque suas datas podem estar no passado. Criar reservas pela API, pelas telas ou pelo Admin sempre aplica as regras.

## Diferenciais

Consulta de disponibilidade (tela e API); mensagens específicas por tipo de erro; validações separadas em `regras.py`; filtros por data e veículo; comando próprio `carregar_dados`.

## Limitações conhecidas

- Sem autenticação de usuários (fora do escopo do PBL 1).
- Duas requisições simultâneas para o mesmo horário poderiam, em teoria, passar pela checagem ao mesmo tempo. Em uso real, seria necessário um banco com controle de concorrência adequado (ex.: bloqueio da linha do veículo).
- Reservas que atravessam a meia-noite não são suportadas: saída e retorno pertencem à mesma data.

## Referência

DJANGO SOFTWARE FOUNDATION. *Django documentation*. Disponível em: https://docs.djangoproject.com/.
