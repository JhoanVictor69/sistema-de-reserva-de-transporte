# Requisitos e regras de negócio — COSEG Mobilidade

Fonte principal: enunciado do PBL 1 (prof. Danilo Costa, 5º período, 2026.2).

## 1. Requisitos funcionais

| Código | Requisito |
|---|---|
| RF01 | O sistema deve manter o cadastro persistente da frota: 8 veículos leves (VL-01 a VL-08, 4 lugares) e 2 coletivos (VC-01 e VC-02, 18 lugares). |
| RF02 | O sistema deve registrar reservas com solicitante, setor, atividade, origem, destino, data, horário de saída, horário de retorno, quantidade de passageiros, veículo e observações. |
| RF03 | O sistema deve permitir listar, consultar, criar, atualizar e excluir reservas (CRUD). |
| RF04 | O sistema deve permitir listar e consultar veículos. |
| RF05 | O sistema deve informar a disponibilidade dos veículos para uma data e um intervalo de horário, opcionalmente considerando a quantidade de passageiros. |
| RF06 | O sistema deve permitir filtrar reservas por data e por veículo. |
| RF07 | O sistema deve retornar mensagens claras de sucesso e de erro (em JSON na API e em tela no formulário). |
| RF08 | O sistema deve oferecer comando para cadastrar a frota e as quatro reservas de referência do enunciado, sem duplicar registros em execuções repetidas. |
| RF09 | O sistema deve oferecer páginas simples (início, veículos, reservas, formulário e disponibilidade) para demonstração. |

## 2. Requisitos não funcionais

| Código | Requisito |
|---|---|
| RNF01 | Implementação em Python 3 com Django e banco SQLite, usando models, migrations, views, URLs e Django ORM. |
| RNF02 | Persistência em banco de dados: nenhum dado de reserva ou frota pode depender de listas em memória. |
| RNF03 | Todas as validações devem ocorrer no servidor, independentemente da interface utilizada. |
| RNF04 | O backend deve funcionar sem a interface HTML (API JSON independente). |
| RNF05 | A proteção CSRF do Django deve permanecer ativa. |
| RNF06 | O projeto deve executar localmente no Windows com VS Code, sem serviços externos. |
| RNF07 | As regras de negócio devem ser verificadas por testes automatizados (Django TestCase). |
| RNF08 | A verificação de "data passada" deve usar o fuso horário configurado no Django (`America/Fortaleza`). |

## 3. Regras de negócio

| Código | Regra |
|---|---|
| RN01 | Veículo leve transporta no máximo 4 passageiros; coletivo, no máximo 18. |
| RN02 | Solicitações com mais de 18 passageiros são rejeitadas, mesmo em veículo coletivo. |
| RN03 | A quantidade de passageiros deve ser de pelo menos 1 (zero e negativos são rejeitados). |
| RN04 | Não é permitido reservar para data anterior à data atual. Na edição de uma reserva cuja data não foi alterada, essa regra não é reaplicada (permite corrigir registros antigos). |
| RN05 | O horário de retorno deve ser posterior ao horário de saída. |
| RN06 | O mesmo veículo não pode ter duas reservas com períodos sobrepostos na mesma data: `nova_saida < retorno_existente` e `novo_retorno > saida_existente`. |
| RN07 | Reservas encostadas (uma termina exatamente quando a outra começa) **não** são conflito. |
| RN08 | Na edição, a própria reserva é ignorada na verificação de conflito. |
| RN09 | Todos os campos, exceto observações, são obrigatórios. |
| RN10 | O veículo informado deve existir; veículo marcado como "fora de operação" não aceita novas reservas. |
| RN11 | Nenhuma reserva inválida é gravada: a validação acontece antes de salvar. |

## 4. Decisões e suposições

- O enunciado cita "veículo ou categoria pretendida". Foi adotado o **veículo** como campo obrigatório; a categoria é consequência do veículo e a consulta de disponibilidade ajuda a escolher.
- As quatro reservas do enunciado não informam solicitante, setor, origem, destino nem passageiros. O comando `carregar_dados` preenche esses campos com valores neutros (passageiros = 1, que é o menor valor válido) e registra isso nas observações. Data, horários, veículo e atividade seguem o enunciado, sem alteração.
- As datas dessas reservas (agosto/2026) podem estar no passado quando o comando for executado. Por isso são gravadas direto pelo ORM, sem passar pela validação de data; novas reservas continuam sujeitas à RN04.
- A API de veículos é somente leitura; a manutenção da frota é feita pelo comando ou pelo Django Admin.
